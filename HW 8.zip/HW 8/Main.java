public class Main {
    public static void main(String[] args) {

        Integer[] A = { 14, 5, 8, 7, 1, 0, 8, 3, 6, 9, 1 };
		Counting.sort(A);
        for(int num: A) {
            // print the values to see if sorted
            System.out.print(num + ", ");
        }

        System.out.println();
        Integer[] B = { 4, 6, 7, 2, 9, 1, 13, 17, 4, 9, 10 };
		Merge.sort(B);
        for(int num: B) {
            // print the values to see if sorted
            System.out.print(num + ", ");
        }
    }
}